export const BACKEND_URL = `https://api.exchangeratesapi.io/`;
export const REQUEST_TIMEOUT = 5000;
export const BASE = "EUR";
