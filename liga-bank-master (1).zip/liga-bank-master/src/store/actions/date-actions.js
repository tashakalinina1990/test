import { DATE } from "./action-types";

export const setDate = (date) => ({
  type: DATE,
  date: date,
});
